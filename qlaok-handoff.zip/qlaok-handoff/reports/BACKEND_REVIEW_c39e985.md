# Review Qlaok

Ngày: 16/10/2026. Snapshot main: c39e985d33bb7ee3f4d95ea020c284a45f23532a.

## Phạm vi và giới hạn

Đã đọc README.md, ARCHITECTURE.md, TODO.md; đối chiếu phần sản phẩm, kiến trúc và RLS trong document.md. Rà soát API auth/admin/shops/catalog/orders/payment, tầng db/mpos/auth credentials, migrations, migration runner và E2E tests. Đây là review các luồng trọng yếu, chưa phải kiểm toán toàn bộ UI/mobile.

Git clone không thành công vì không kết nối được proxy. Code được đọc qua kết nối GitHub ở commit cố định trên; thư mục snapshot chỉ là các file tham chiếu đã đọc, không phải bản clone Git đầy đủ. Không sửa repo upstream, không gọi API production, không chạy migration hoặc thao tác dữ liệu thật.

Đã chạy mã mpos-store.ts trong môi trường cô lập bằng Node 24, thay import Supabase bằng mock và dùng thư mục tạm. Năm ca tái hiện đều thành công (xác nhận lỗi). Chưa chạy build/typecheck/test suite của dự án vì chưa cài đầy đủ dependencies và môi trường. Không có kết luận về trạng thái database đang triển khai.

## Phát hiện theo ưu tiên

### 1. P0 — API admin tin email do người gọi tự khai

Vị trí: src/app/api/admin/route.ts:46–51, GET:54 và POST:361.

verifySuperAdminRequest chỉ so sánh x-admin-email/query adminEmail/body adminEmail với email cố định. Không xác thực access token hoặc session. Bất kỳ người gọi nào biết email công khai trong repo đều vượt qua kiểm tra, từ đó có thể gọi các nhánh quản trị như đổi gói, reset mật khẩu, xóa dữ liệu.

Đề xuất: xác thực session trên server bằng Supabase Auth, lấy user ID từ token đã kiểm tra; tra quyền admin từ nguồn server quản lý, không nhận quyền từ email/header/localStorage. Với thao tác nhạy cảm bổ sung audit log.

### 2. P0 — Đăng ký có thể ghi đè mật khẩu admin; sync_user không chứng minh danh tính

Vị trí: src/app/api/auth/route.ts:82–105 và :307 trở đi; src/lib/auth-credentials.ts:21–25, :93–100.

Nhánh register đặc biệt cho email admin ghi đè credential chỉ bằng email/password đầu vào, không yêu cầu mật khẩu cũ hay xác nhận email. Nhánh sync_user nhận email/userId từ body, trả hồ sơ cùng cờ admin theo email, không kiểm tra Supabase token. Mật khẩu admin mặc định cũng được hardcode; mật khẩu local dùng SHA-256 với tiền tố cố định.

Đề xuất: bỏ nhánh register ghi đè admin, bỏ credential store và mật khẩu mặc định; thống nhất Supabase Auth. sync_user lấy ID/email từ user đã xác thực. Reset mật khẩu qua recovery flow chuẩn. Không dùng profile JSON trong localStorage làm bằng chứng đăng nhập.

### 3. P0 — RLS bật nhưng cho phép toàn bộ thao tác

Vị trí: supabase/migrations/001_init_qlaok.sql:231–263 và 002_mpos_orders_inventory.sql:32–34.

Các policy FOR ALL USING (true) WITH CHECK (true) không phân tách người dùng/cửa hàng. Với role có table grants, policy cho phép đọc và ghi mọi dòng, gồm profiles, payment_transactions và orders. Publishable/anon key trong client không phải bí mật nên không thể thay thế phân quyền.

Đề xuất: tạo migration MỚI xóa policy mở; policy owner dựa trên auth.uid() và quan hệ shops.owner_id; public chỉ đọc dữ liệu storefront được công bố. Profiles không cho client đổi plan/role. Payment chỉ ghi qua backend đã kiểm chứng. Đối chiếu kiểu ID: schema đang dùng TEXT và có ID demo tùy biến, cần ánh xạ rõ auth user UUID thay vì chép nguyên policy trong document.md.

Lưu ý: chỉ sửa file 001 là chưa đủ cho database đã triển khai. Migration runner hiện chạy lại toàn bộ SQL; nếu giữ các câu tạo policy mở trong migration cũ, cần bảo đảm migration mới chạy sau và chuyển sang cơ chế ghi lịch sử migrations.

### 4. P0 — API nghiệp vụ không kiểm tra chủ sở hữu

Vị trí: src/app/api/shops/route.ts:36–58; catalog/route.ts:20–58; orders/route.ts:18 trở đi và PATCH.

CRUD nhận owner_id/shopId/itemId/orderId từ client rồi gọi DB, không có session/ownership check. API shops PATCH chuyển toàn bộ patch xuống dbUpdateShop (:430–455), có thể sửa trường ngoài phạm vi UI. GET orders trả danh sách đơn, tồn kho và doanh thu theo shopId cho người chưa đăng nhập.

Đề xuất: middleware/helper dùng chung requireUser + requireShopOwner trên server; allowlist trường được sửa. Tách API khách tạo/theo dõi đơn khỏi API nhân viên quản lý đơn. Khách chỉ nhận dữ liệu cần thiết bằng token theo dõi riêng. Kiểm tra cả RLS lẫn API, nhất là khi backend dùng service role.

### 5. P0 — Nâng gói không cần xác nhận thanh toán

Vị trí: src/app/api/webhooks/payment/route.ts:22–60; src/lib/db.ts:985–1043.

switch_plan_direct công khai gọi dbSetProfilePlan. Webhook không kiểm tra chữ ký/secret hoặc số tiền; dbCompletePaymentWebhook còn tự tạo giao dịch completed khi mã chưa tồn tại. Payload lặp lại vẫn cập nhật ngày hết hạn. amount tạo giao dịch cũng lấy từ body.

Đề xuất: bỏ switch_plan_direct khỏi production; server quyết định giá theo gói. Tách API tạo payment cho user đăng nhập và webhook nhà cung cấp. Xác minh chữ ký, mã pending đã tồn tại, amount/currency/tài khoản nhận; unique bank reference và transaction atomic cho chuyển pending -> completed + nâng gói. Retry phải trả kết quả cũ, không gia hạn lại.

### 6. P1 — Giá và trường thanh toán do khách quyết định

Vị trí: src/lib/mpos-store.ts:686–718, :740–767; src/app/api/orders/route.ts POST.

Code tải catalog nhưng không dùng giá catalog để tính tiền; tổng tiền dùng unit_price/extra_price/discount_amount từ body. Không từ chối item không thuộc cửa hàng. Khách có thể gửi payment_status paid hoặc markCompletedImmediately để tạo đơn hoàn tất/đã trả tiền.

Kiểm chứng: món catalog giá 50.000, gửi unit_price=1 -> đơn có total_amount=1.

Đề xuất: input khách chỉ gồm item ID, số lượng và choice IDs; server tính giá và topping từ catalog, kiểm tra món thuộc shop và các option hợp lệ. Chỉ staff được giảm giá/đánh dấu trả tiền/hoàn tất.

### 7. P1 — Số lượng âm và dòng trùng làm sai tồn kho

Vị trí: src/lib/mpos-store.ts:702–733.

Không validate quantity là số nguyên dương. Kiểm tra tồn từng dòng độc lập trước khi trừ kho nên các dòng cùng item đều vượt qua dù tổng vượt tồn.

Kiểm chứng: tồn 5, quantity=-2 -> tồn 7. Hai dòng cùng món, mỗi dòng 4 -> đơn 8 được chấp nhận khi tồn chỉ 5.

Đề xuất: runtime schema validation, giới hạn số dòng/số lượng; gộp nhu cầu theo item ID trước khi kiểm tra. Kiểm tra giá trị hữu hạn và không âm; option khác nhau vẫn cộng cùng nhu cầu tồn của item.

### 8. P1 — Ghi JSON và đồng bộ DB không atomic

Vị trí: src/lib/mpos-store.ts:593–644, :679–700, :772–799.

Đọc JSON trước await truy vấn items rồi ghi lại toàn bộ file. Hai request có thể cùng đọc tồn cũ và ghi đè kết quả nhau, mất đơn local hoặc sai tồn. Ghi orders và items ở Supabase là nhiều thao tác riêng; phần lớn không kiểm tra trường error. Supabase trả lỗi dưới dạng result nên catch không bắt được. Không có hàng đợi retry/reconciliation bền vững.

Kiểm chứng: hai request đồng thời, mỗi request mua 4 trong tồn 5, đều được chấp nhận; tồn cuối 1 thay vì từ chối một đơn.

Đề xuất: chọn PostgreSQL làm nguồn dữ liệu chính; tạo order + trừ kho trong một RPC/transaction, lock hàng theo thứ tự ổn định hoặc conditional update. Thêm idempotency key chống gửi lặp. Chỉ trả success khi commit. Nếu cần offline POS thật, thiết kế outbox và quy tắc xử lý xung đột riêng; không xem JSON hiện tại là đồng bộ offline đáng tin cậy.

### 9. P1 — Mở lại đơn hủy không trừ lại kho

Vị trí: src/lib/mpos-store.ts:825, :862, :917–937.

Không có state machine. Khi PATCH cancelled -> new mà không thay items, code đổi trạng thái nhưng không trừ lại lượng đã hoàn. Hủy tiếp lại cộng thêm kho.

Kiểm chứng: tồn 5 -> mua 2 -> hủy -> mở lại -> hủy; tồn cuối 7.

Đề xuất: quy định các transition hợp lệ. Nếu không cần phục hồi đơn thì từ chối mở lại; nếu có, reserve lại tồn trong cùng transaction. Tách trạng thái phục vụ khỏi trạng thái thanh toán; completed không tự đồng nghĩa đã thu tiền trong mọi nghiệp vụ.

### 10. P1 — Tài liệu công khai chứa chuỗi API key và thông tin đăng nhập mặc định

Vị trí: README.md:87; src/lib/auth-credentials.ts:93–100; tree có .env và mobile/.env được track.

README chứa chuỗi AI_API_KEY cụ thể. Chưa xác minh key còn hoạt động; không tái xuất giá trị trong báo cáo. File .env được track cần kiểm kê từng biến: publishable Supabase key khác với secret/service-role/AI key.

Đề xuất: thu hồi/rotate key nếu đã cấp thật; bỏ secret khỏi file và Git history, chuyển sang env/secret store. .env.example chỉ dùng placeholder. Bỏ tài khoản admin mặc định. Bổ sung secret scanning trong CI.

## Hiệu năng và bảo trì

- loadMergedOrders (:605–608) query tất cả orders, rồi mới lọc shop tại :647–648; GET đơn theo ID cũng tải tất cả. Dashboard poll liên tục sẽ làm tăng tải theo tổng dữ liệu toàn hệ thống. Đưa shop/id/date filter vào SQL, phân trang; aggregate doanh thu trên DB; cân nhắc Realtime sau khi sửa phân quyền.
- dbGetStorefrontBundle (:255–261) chưa lọc is_published, khác yêu cầu public chỉ xem cửa hàng published trong document.md. Cần thống nhất contract public và dashboard.
- Auth/admin cùng dữ liệu demo chạy trong luồng thật; tách seed thành lệnh opt-in cho môi trường dev, không seed admin khi xử lý request.
- Tách component lớn như admin/page.tsx và PosCounterWorkspace.tsx sau khi ổn định logic nghiệp vụ. Ưu tiên module domain orders/inventory/billing có contract rõ thay vì refactor UI trước.
- Migration runner chạy mọi file SQL mỗi lần, chưa có history/checksum/lock. Dùng migration tracking để tránh chạy lại schema cũ và ghi đè policy đã sửa.
- README/ARCHITECTURE/TODO mô tả khác nhau về auth, AI, local fallback và realtime; document.md mô tả owner RLS nhưng migrations cho all-access. Chọn tài liệu kiến trúc hiện hành, đánh dấu phần demo và phần production.

## Thứ tự triển khai đề xuất

1. PR bảo mật auth/admin/API ownership và migration khóa RLS; giữ public menu hoạt động.
2. PR thanh toán: bỏ đường demo production, xác minh webhook và idempotency.
3. PR orders/inventory: validate input, server tính tiền, state machine, transaction DB.
4. PR test và CI: typecheck/build/unit, integration trên database test biệt lập, không dùng production. Có thể bổ sung negative tests cùng từng PR trên.
5. PR hiệu năng và docs: query theo shop, pagination/aggregate, cập nhật tài liệu, tách component.

## Các test phải có trước khi mở sử dụng thật

- Anonymous/owner A không được đọc hoặc sửa tài nguyên owner B; giả email admin vẫn nhận 401/403.
- Register và sync_user không chiếm được admin; token hết hạn/sai bị từ chối.
- Webhook sai chữ ký, sai tiền, mã lạ bị từ chối; retry không gia hạn lần hai.
- Giá client không ảnh hưởng giá server; quantity âm/0/lẻ/không hữu hạn, item khác shop, option lạ bị từ chối.
- Dòng trùng, nhiều đơn đồng thời và request retry không vượt kho hoặc tạo đơn lặp.
- Hủy lặp/mở lại/hủy không sinh thêm tồn; lỗi DB rollback toàn bộ.
- Public storefront không lộ cửa hàng chưa publish.

tests/e2e.test.mjs hiện gọi switch_plan_direct và ghi/xóa dữ liệu qua TEST_BASE_URL. Chưa chạy suite này vì chưa có môi trường test biệt lập; suite hiện thiên về happy path, chưa thay thế các kiểm tra phân quyền và cạnh tranh trên.

## Chạy lại kiểm chứng cô lập

node --experimental-strip-types /workspace/qlaok-review/verification/verify.mjs

verification/mpos-isolated.ts giữ logic nguồn và thay duy nhất import kiểu dữ liệu/import Supabase để mock. Mock không kiểm tra RLS, network hoặc tính nguyên tử PostgreSQL; kết quả chỉ chứng minh năm lỗi logic nêu trên.

