# Bàn giao phiên Qlaok sang Local

Đọc CONTEXT.md trước, rồi reports/WORKFLOW_REVIEW.md và reports/MOBILE_REVIEW.md.
NEXT_PROMPT.md là lời nhắc có thể dán vào Codex Local hoặc Antigravity.

Đây là gói bàn giao ngữ cảnh và các artifact thực tế của phiên cloud. Không phải định dạng import hội thoại gốc của ChatGPT/Codex; không chứa toàn bộ tool logs hay transcript nguyên văn câu trả lời. USER_REQUESTS.md lưu các yêu cầu người dùng và CONTEXT.md giữ quyết định, kết quả, giới hạn cùng việc còn lại.

## Cách tiếp tục

1. Giải nén gói này ngoài thư mục source đang làm, hoặc vào một thư mục handoff riêng.
2. Mở repo local hoangvu96z/qlaok trong Codex Local / Antigravity.
3. Dán NEXT_PROMPT.md, sửa đường dẫn gói bàn giao cho đúng.
4. Agent đọc AGENTS.md của repo local, kiểm tra git status và HEAD/branch trước khi làm. Không ghi đè thay đổi chưa commit.
5. Đối chiếu code local với commit được review; các lỗi có thể đã được sửa sau snapshot.

Không copy đè snapshots/ lên repo: đó là các file tham chiếu chưa đầy đủ, có cả code cũ. Không phải full clone, không có .git/dependencies/.env hay database dump.

## Nội dung

- CONTEXT.md: mục tiêu, lịch sử, trạng thái, quyền và việc tiếp theo.
- USER_REQUESTS.md: yêu cầu của người dùng.
- NEXT_PROMPT.md: lời nhắc tiếp tục.
- reports/: ba báo cáo review.
- artifacts/: snapshot code và các bài kiểm chứng cô lập từ cloud.
- MANIFEST.json: danh sách, kích thước, SHA-256 các file (không gồm chính manifest).

Bản review backend đầu dùng c39e985d33bb7ee3f4d95ea020c284a45f23532a.
Bản mobile/workflow mới hơn dùng 7863dd77f81abaf7cca13a6caba945f03be826f8.
Một số lỗi backend đầu đã được thay đổi ở bản sau; ưu tiên đối chiếu báo cáo workflow và code local hiện tại.

Không có commit/push/deploy upstream nào từ phiên cloud.

