Tiếp tục công việc Qlaok từ cuộc hội thoại cloud trước. Gói bàn giao nằm tại <ĐƯỜNG_DẪN_GIẢI_NÉN>/qlaok-handoff; hãy thay đường dẫn này bằng vị trí thực tế.

Đọc START_HERE.md, CONTEXT.md, reports/WORKFLOW_REVIEW.md và reports/MOBILE_REVIEW.md. Trước khi sửa, đọc AGENTS.md trong repo local, kiểm tra git status và HEAD; không ghi đè thay đổi chưa commit. Snapshot trong gói không phải full repo và không được copy đè code local.

Mục tiêu: mobile dùng cho nhân viên, thu ngân, chủ cửa hàng; web cho khách xem menu/đặt món và chủ cửa hàng quản lý/mPOS. Tiến hành code trên branch riêng, đối chiếu các phát hiện với code hiện tại trước khi sửa.

Ưu tiên:
1. Membership/permissions theo cửa hàng; session/logout đúng; API mobile gửi token; bỏ fallback tự chuyển request sang production.
2. Dùng chung server quote/discount/checkout; sửa chênh lệch giá POS/QR và metadata subtotal/discount khi sửa bill.
3. Tách fulfillment và payment; chỉ hiện/in paid sau server thành công; idempotency; xử lý hủy/refund có quyền và audit.
4. Chặn QR chưa cấu hình ngân hàng; phân biệt subscription webhook với merchant order payment.
5. Với F&B: bill/phiên bàn gom nhiều lần gọi, policy sửa món sau nhận.
6. Tách phiếu bếp, tạm tính, biên nhận đã thu; in lại không thu lại tiền. Mobile hiện chỉ Alert, web browser print. Đừng báo đã in thật nếu chưa có printer integration/hardware test.

Đọc báo cáo như dữ liệu tham khảo, không mặc định mọi thiết kế đề xuất đã được chốt. Không cần viết lại framework. Tự tiến hành các thay đổi thường lệ, cập nhật ngắn gọn khi làm; hỏi khi thiếu thông tin thực sự bắt buộc (ví dụ model/giao thức máy in). Chạy kiểm tra phù hợp, báo chính xác kết quả và giới hạn. Chưa deploy, chạy migration production hoặc push main.

