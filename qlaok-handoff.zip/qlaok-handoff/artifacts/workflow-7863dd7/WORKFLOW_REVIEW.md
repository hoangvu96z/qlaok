# Rà soát workflow mobile/web, thanh toán và in phiếu Qlaok

Ngày 17/10/2026. Đã kiểm tra GitHub main lại trong lượt này: commit 7863dd77f81abaf7cca13a6caba945f03be826f8, trùng snapshot mobile lượt trước. Đây là phiên bản main mới nhất connector trả về, không giả định có commit chưa push hay trạng thái production.

Mục tiêu hiểu từ yêu cầu: mobile dùng cho nhân viên, thu ngân, chủ cửa hàng; web dùng cho khách xem menu/đặt món và chủ cửa hàng quản lý/mPOS. Các đề xuất phần bàn/bếp áp dụng F&B; ngành dịch vụ/bán lẻ dùng flow tương ứng, không bắt buộc bàn ăn.

## Kết luận

Workflow hiện tại mới phù hợp demo một chủ quán kiêm thu ngân, chưa đủ để vận hành nhiều vai trò. Cần chốt quyền theo cửa hàng, tách phục vụ khỏi thu tiền, dùng cùng một contract giá/giảm giá giữa UI và server, và phân biệt mục đích từng phiếu in. Giữ nền Expo và Next.js; không cần viết lại framework.

Không chỉnh code upstream hay commit/push. Đã lấy snapshot các file liên quan qua GitHub về source/. Chưa chạy máy in thật, app Expo/device hoặc DB integration. verification/ chạy engine hiện tại với Supabase mock, trong thư mục tạm, không kết nối production.

## 1. Code hiện có gì đúng

- Khách đặt QR tạo đơn new/unpaid; chọn VietQR không đồng nghĩa đã chuyển tiền.
- Backend đã thêm kiểm tra session/owner cho thao tác quản lý đơn.
- Engine mới lấy giá catalog từ server, kiểm tra quantity và gộp demand tồn; giữ hai trường status và payment_status riêng.
- Web POS QR gọi submitPosOrder(false, true): lưu đơn unpaid rồi mở phiếu có QR, hợp lý cho thanh toán sau.
- Web handleUpdateOrder thông thường chỉ dùng response khi res.ok trước khi mở receipt.
- In web gọi browser print qua iframe, không tự đặt paid chỉ vì nhấn in. Tách hai hành động này là đúng.
- Trả tiền trước khi làm món là tình huống hợp lệ: new/paid hoặc preparing/paid có thể tồn tại, không nên ép mọi paid thành completed.

## 2. Các điểm lệch workflow, kèm code

### F01. P1 — Chưa có nhân viên/thu ngân theo cửa hàng

source/src/lib/server-auth.ts:13–18, :294 trở đi chỉ có role owner/admin và requireShopOwnerOrAdmin so owner_id. source/src/types/qlaok.ts và các migration đã đọc chưa có shop_memberships/permissions cho staff/cashier.

Mobile source/mobile/App.tsx:40 mặc định logged in; logout :528 chỉ đổi flag. Các REST call không gửi token. Selector shops :210–213 không lọc owner. RLS public đọc quán published không thể thay bộ chọn quán làm việc của nhân viên.

Tác động: không thể cấp người phục vụ quyền nhận đơn mà cấm thu tiền, hoặc thu ngân quyền bán hàng mà cấm sửa ngân hàng/nhân sự. Chỉ ẩn tab không giải quyết quyền API/RLS.

### F02. P1 — Một hành động đang trộn phục vụ và thu tiền

- mobile OrdersTab.tsx:250, web orders/page.tsx:960–962 gửi completed + paid cùng lúc.
- Web QR confirm :1123–1128 đặt paid + completed dù đơn có thể chưa làm.
- Cùng màn hình, onConfirmPaid ở :1495–1503 lại chuyển new -> preparing khi thu tiền.
- POS cash :711 tạo paid nhưng không markCompletedImmediately; server mpos-store.ts:1045 giữ new. Điều này hợp lệ cho quán trả trước, nhưng chưa được diễn giải thành một policy rõ trong UI.
- Backend update chỉ cấm completed -> new (:1126), chưa là state machine đầy đủ phù hợp từng vai trò.

Cần cho phép độc lập:
1) Đã phục vụ nhưng chưa trả tiền.
2) Đã trả tiền nhưng đang làm món.
3) Đơn kết thúc khi phục vụ xong và bill đã được xử lý thanh toán.

Không dùng nút “Đã phục vụ” của nhân viên để mặc nhiên ghi nhận tiền vào quỹ.

### F03. P1 — Xác nhận tiền có thể hiện thành công dù API lỗi

Mobile App.tsx:287–315 mở receipt paid trước request và không check res.ok. Đã kiểm chứng ở lượt trước với 403.

Web orders/page.tsx:302–334 không throw/return failure cho non-2xx; callback receipt :1495–1507 await xong vẫn setPrintingOrder paid. Vì vậy một response 401/403/500 có thể làm preview thành “đã thu tiền” dù backend chưa đổi.

Đề xuất: confirmPayment trả canonical bill/order hoặc throw lỗi. Chỉ mở/in biên nhận paid từ response thành công. Chống double tap, pending theo bill, idempotency key, giữ lỗi hiển thị để thu ngân xử lý.

### F04. P1 — Giá giảm trên UI không khớp backend

POSCounterWorkspace.tsx:660–675 giảm giá bằng cách hạ unit_price; payload :692–715 không gửi discount_amount tương ứng. Server validateAndPriceOrderLines mpos-store.ts:678–681 ghi đè unit_price bằng catalog kể cả caller là staff.

ShowToStaffModal.tsx:299 hiển thị grandTotal có promotion; POST :361 gửi discount_amount. Backend :1022–1027 cho guest discount=0, không tự áp rule promotion cấu hình quán.

Kiểm chứng:
- Catalog 100.000, POS gửi unit_price 80.000 -> backend lưu tổng 100.000.
- Khách QR gửi discount 20.000 -> backend lưu discount=0, tổng 100.000.

Server authoritative pricing là đúng, nhưng cần biểu diễn ý định giảm giá bằng rule/voucher/permission, không dựa vào giá đã hạ từ client. Trước khi yêu cầu thanh toán, dùng số tiền quote do server trả và báo rõ nếu giá đổi.

### F05. P1 — Sửa đơn giữ subtotal/discount cũ, làm phiếu in sai

mpos-store.ts:1220–1236 tính lại total khi thay items; updated object :1285–1301 không cập nhật subtotal_amount/discount_amount. ReceiptPrintModal.tsx:41–44 ưu tiên field cũ.

Kiểm chứng: đơn ban đầu subtotal 100.000; sửa thành 2 món, discount 20.000 -> total=180.000 nhưng subtotal_amount vẫn 100.000 và discount_amount=0. Receipt có thể không hiện giảm giá dù tổng đã giảm.

Cần lưu atomically subtotal, từng discount, total và phiên bản bill; in từ snapshot server cùng phiên bản.

### F06. P1 — Tiền VietQR đơn hàng chưa có đối soát tự động

src/app/api/webhooks/payment/route.ts xử lý targetPlan, QLAOK plan orders và dbCompletePaymentWebhook, là tiền mua gói SaaS. Không phải webhook cập nhật thanh toán đơn mPOS.

Hiện QR đơn hàng chỉ tạo ảnh + nội dung CK; thu ngân bấm đã nhận tiền bằng tay. Đây có thể là MVP hợp lệ nếu ghi rõ xác nhận thủ công và lưu người xác nhận, thời gian, số tiền, phương thức/reference.

Nếu muốn tự động: cần merchant payment riêng gắn shop/bill/payment attempt, kiểm tra tài khoản nhận, amount, transaction ID; webhook idempotent. Không lấy ảnh chụp/khách bấm đã chuyển hay việc in QR làm bằng chứng thanh toán.

Mã ORD hiện là 3 chữ số ngẫu nhiên (mpos-store.ts:1031–1040), không phù hợp làm khóa đối soát duy nhất cho nhiều ngày/cửa hàng. Dùng ID/reference duy nhất phía server; số thứ tự ngắn chỉ để nhân viên đọc.

### F07. P1 — Chưa cài ngân hàng vẫn trả QR tài khoản fallback

payment-qr.ts:229–246 trả QR có tài khoản fallback khi thiếu cấu hình, isConfigured=false. Modal web QR có cảnh báo nhưng vẫn hiển thị QR; ShowToStaffModal và ReceiptPrintModal không gate theo isConfigured. Khách/in giấy có thể nhìn QR không phải tài khoản cửa hàng.

Cần chặn tạo/hiển thị/in QR thanh toán nếu thiếu cấu hình; hiển thị phương án tiền mặt hoặc gọi thu ngân. Không dùng QR chuyển khoản thật cho demo fallback. QR ảnh tĩnh custom không tự bảo đảm đúng amount/reference; UI không nên hứa đã điền sẵn.

### F08. P1 — Sửa đơn khách đang hiển thị nhưng API không cho

ShowToStaffModal.tsx:607–624 cho sửa mọi đơn chưa paid và chưa cancelled, gồm preparing. Gửi PATCH :338–351; API orders PATCH chỉ owner/admin. Khách bình thường không có quyền nên thao tác thất bại.

Cần chọn policy: khách được sửa trước quán nhận qua tracking token và state guard; sau khi nhận chỉ gửi yêu cầu đổi/hủy cho nhân viên duyệt. Hoặc bỏ nút sửa, chỉ tạo yêu cầu bổ sung rõ ràng. Không mở toàn bộ PATCH quản trị cho khách để sửa lỗi UI này.

Tracker GET hiện không gửi trackingToken (:244), backend chỉ reject khi token có truyền mà sai. Cần kiểm tra bắt buộc token cho customer tracking và cập nhật client cùng lúc để không lộ chi tiết đơn.

### F09. P1 — Chưa có bill/phiên bàn gom các lần gọi món

ShopOrder hiện chỉ có table_label, không có dining session/bill ID. Khách “gọi thêm” tạo order mới, chưa có cơ chế bill gộp nhiều đợt, chuyển bàn/tách/gộp hoặc giải phóng bàn có ràng buộc.

Với quán ăn thanh toán cuối bữa, cần bill/visit để gom các order rounds; tránh thu thiếu khi một bàn có 3 đơn. Với café/retail trả trước từng lần, một order = một bill là đủ ở MVP nhưng phải chốt policy theo shop, không suy từ nhãn bàn.

QR bàn nên gắn table ID; khách không tự chọn số bàn tùy ý thay cho ràng buộc phiên phục vụ.

### F10. P1/P2 — In mobile là mô phỏng; web chưa có print workflow hoàn chỉnh

- mobile ReceiptModal.tsx:314–319 chỉ Alert rồi đóng; chưa có printer call.
- Web ReceiptPrintModal.tsx:61–260 gọi browser print, có thể in qua driver đã cài; chưa phải silent/direct ESC/POS.
- autoPrintOnPay trong web chủ yếu mở modal receipt; modal vẫn cần bấm in, không tự gửi job.
- Receipt includeQr mặc định true (:32), cả đơn paid/cash vẫn có CTA chuyển khoản (:118–132). Nên mặc định ẩn QR thu tiền trên biên nhận đã trả để tránh khách trả lần hai.
- Tên HTML luôn “HÓA ĐƠN THANH TOÁN” (:170), kể cả unpaid; cần ghi “PHIẾU TẠM TÍNH — CHƯA THANH TOÁN” rõ ràng khi chưa thu.
- Chưa thấy print job, attempt, printed_by hay reprint reason. Không thể báo in thành công từ việc mở print dialog.
- Chưa có phiếu bếp riêng, routing máy in hoặc in delta khi thêm món; in lại full bill xuống bếp dễ làm món hai lần.

### F11. P1/P2 — Hủy đơn đã trả tiền và doanh thu chưa theo ledger

Backend cho hủy paid order và hoàn tồn, vẫn giữ payment_status=paid; không có refund transition/transaction. Kiểm chứng mock tái hiện đúng. Hủy món đã chế biến không mặc nhiên hoàn nguyên nguyên liệu như món chưa làm; cần reason/waste policy.

computeShopRevenueAndInventoryStats :1348–1367 cộng mọi order không cancelled, kể cả unpaid. Cần phân biệt doanh số đặt hàng, tiền đã thu, tiền hoàn và doanh thu thuần. Cashier cần chốt ca theo payment ledger, không dựa vào tổng đơn chưa hủy.

## 3. Workflow đề xuất theo vai trò

| Tác vụ | Khách web | Nhân viên mobile | Thu ngân mobile | Chủ mobile/web |
|---|---|---|---|---|
| Xem menu, đặt món, theo dõi đơn của mình | Có | Có khi tạo hộ khách | Có | Có |
| Nhận đơn, báo bếp, cập nhật phục vụ | Không | Có | Theo quyền quán | Có |
| Gửi phiếu bếp / in lại phiếu bếp | Không | Theo quyền, ghi log | Có | Có |
| In tạm tính / QR thu tiền | Xem bill của mình | Có thể cấp riêng | Có | Có |
| Xác nhận tiền mặt/chuyển khoản | Không | Không mặc định | Có | Có |
| Giảm giá, sửa giá, hủy món | Yêu cầu | Theo hạn mức/duyệt | Theo quyền/hạn mức | Có, lưu log |
| Hoàn tiền, sửa bill đã trả | Không | Không | Yêu cầu/được cấp riêng | Duyệt theo policy |
| Chốt ca, xem quỹ ca mình | Không | Không | Có | Có |
| Xem toàn bộ doanh thu/nhân sự/ngân hàng | Không | Không | Không mặc định | Có |

Quyền gắn shop_membership (shop_id, user_id, role, permissions, active), không gắn vai trò duy nhất toàn tài khoản. Một người có thể thu ngân shop A và nhân viên shop B. Server và RLS dùng cùng membership; UI chỉ trình bày quyền đã xác thực.

Chủ mobile dùng overview và quản trị; nhân viên vào Orders/Tables; thu ngân vào Bills/Checkout. Một app theo role, không cần ba app riêng. Web khách không đăng nhập bắt buộc; dùng token scope nhỏ cho visit/order của khách. Web chủ dùng cùng API nghiệp vụ với mobile, không có logic thanh toán riêng.

## 4. Luồng vận hành chuẩn

### Quán ăn thanh toán sau

1. Khách quét QR bàn -> mở phiên bàn/bill đang hoạt động hợp lệ.
2. Chọn món -> server quote giá/options/promotion -> gửi request có idempotency key -> đơn chờ nhận, chưa trả tiền.
3. Nhân viên nhận -> ticket bếp ghi đúng món/ghi chú/số bàn; bếp làm xong -> nhân viên giao món. Tiền không thay đổi.
4. Gọi thêm tạo đợt món mới gắn cùng bill; phiếu bếp chỉ in phần thêm/hủy, không in lại toàn bộ món cũ.
5. Khách yêu cầu thanh toán -> thu ngân kiểm tra bill, áp ưu đãi có quyền -> chốt phiên bản tổng tiền -> in tạm tính hoặc cho xem QR.
6. Tiền mặt: nhập tiền khách đưa, tính trả lại; xác nhận đủ tiền. Chuyển khoản: đối soát merchant webhook hoặc thu ngân kiểm tra thực nhận rồi xác nhận thủ công.
7. Server ghi payment thành công -> trả bill đã trả -> mới in biên nhận đã thu. Print fail không rollback khoản tiền đã thu.
8. Khi phục vụ và thanh toán đều xong, đóng bill/phiên bàn; chủ/thu ngân chốt ca theo payments/refunds.

### Café/retail thu tiền trước

Chọn hàng -> quote/chốt bill -> thanh toán -> biên nhận paid -> tiếp tục preparing/ready/served nếu còn khâu chế biến. Thanh toán thành công không tự báo đã giao hàng.

Không bắt buộc bảng session cho retail; cùng engine thanh toán nhưng order fulfillment phù hợp ngành.

## 5. Ba loại phiếu phải tách

| Phiếu | Khi tạo/in | Nội dung | Có thay đổi thanh toán không |
|---|---|---|---|
| Phiếu bếp/bar | Sau khi nhận đợt món | Bàn, món, số lượng, tùy chọn/ghi chú, lần gọi, thêm/hủy | Không |
| Phiếu tạm tính | Khi khách yêu cầu hoặc checkout | Items, giảm giá, tổng, QR đúng bill version, nhãn chưa thanh toán | Không |
| Biên nhận đã thu tiền | Sau server xác nhận payment | Bill/payment ID, thời gian thu, người thu, phương thức, tiền nhận/trả lại | Không; chỉ phản ánh payment đã commit |

In lại ghi “BẢN IN LẠI”, log actor/reason/attempt; in lại không tạo payment hay thêm đơn. Đổi giá sau khi phát QR/tạm tính cần tạo bill version mới và thông báo rõ tổng cũ không còn áp dụng. Khi đã trả, khóa items/total; sửa sai qua adjustment/refund được cấp quyền.

## 6. Mô hình trạng thái tối thiểu

Fulfillment:
submitted -> accepted -> preparing -> ready -> served
cancel/reject có guard theo trạng thái; việc mở rộng thêm ready/served là đề xuất, hiện code chưa có.

Payment:
unpaid -> pending (nếu có kiểm tra giao dịch) -> paid -> partially_refunded/refunded
partial payment có thể để phase sau nếu MVP chỉ thanh toán một lần.

Bill:
open -> checkout -> paid/closed (hoặc void khi chưa thu)
bill đóng phải tuân thủ policy phục vụ và tiền, không suy ra chỉ từ một status order.

Print job:
queued -> sending -> sent/failed; ghi attempted/reprinted.
Chỉ gọi trạng thái printed khi thiết bị/integration thực sự hỗ trợ xác nhận; browser print cần thể hiện giới hạn xác nhận.

Các entity triển khai dần: shop_memberships, tables/dining_sessions, orders/order_items, bills/bill_lines (snapshot giá), payments/refunds, print_jobs, cash_shifts, audit_logs.

## 7. Thứ tự triển khai thực tế

1. Chốt quyền và hai policy checkout (trả trước/trả sau); triển khai memberships/auth API cho mobile.
2. Một service quote + checkout + confirmPayment dùng chung mobile/web; sửa giảm giá, metadata bill, lỗi API và chặn QR chưa cấu hình.
3. Tách fulfillment/payment và xử lý hủy/refund; khóa bill đã trả, audit log và idempotency.
4. Tách phiếu bếp/tạm tính/biên nhận, chọn printer hardware cho mobile; web browser print có thể dùng trước.
5. Với F&B thêm phiên bàn/bill gộp; merchant webhook và chốt ca theo nhu cầu rollout. Push nền cho nhân viên/thu ngân nếu phải nhận đơn khi khóa máy.

## 8. Bằng chứng kiểm chứng

Chạy:
node --experimental-strip-types /workspace/qlaok-review/workflow-7863dd7/verification/verify.mjs

5 ca tái hiện (mock Supabase, source engine giữ nguyên ngoài import):
- POS cash hiện tạo new + paid (hợp lệ trả trước, cần UI rõ).
- Guest discount 20.000 bị bỏ, backend thu 100.000.
- POS giảm unit price xuống 80.000 bị server đổi lại 100.000.
- Cancel paid order trả tồn, vẫn paid, không có refund.
- Edit bill tổng 180.000 nhưng giữ subtotal cũ 100.000/discount 0.

Chưa kiểm thử integration và chưa xác minh database đang deploy. Hardware cần kiểm thử máy in thật. Các lỗi trên là kết quả đọc code và kiểm chứng cô lập, không phải báo cáo giao dịch production.

