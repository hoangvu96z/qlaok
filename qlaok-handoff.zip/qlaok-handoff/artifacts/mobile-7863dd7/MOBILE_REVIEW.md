# Review mobile Qlaok

Snapshot main: 7863dd77f81abaf7cca13a6caba945f03be826f8, ngày 17/10/2026.

Đọc toàn bộ 17 file nguồn/cấu hình/tài liệu mobile (không đọc lockfile và metadata .expo); đối chiếu server-auth.ts, API orders/shops, các migration và engine mPOS hiện tại. Snapshot mới khác bản review backend c39e985: backend đã có xác thực và migration 003. Không suy ra trạng thái triển khai production từ code.

Code tham chiếu nằm trong mobile/ cạnh báo cáo này, backend-reference/ chứa phần đối chiếu. Đây là snapshot qua GitHub, không phải clone Git đầy đủ. Không chỉnh sửa upstream, không commit/push, không chạy app trên thiết bị hay build Expo. Các kiểm chứng bên dưới chạy code trích xuất, với network/state đều mock.

## Kiến trúc hiện tại

- Expo SDK 52, React Native 0.76.9, React 18.3.1, TypeScript strict.
- App.tsx 897 dòng giữ auth flag, danh sách quán, quán đang chọn, catalog/analytics, form settings và promotions; điều phối 5 tab.
- Tab Orders / Overview / Catalog / Promotions / Settings đã tách component; dùng memo.
- useShopRealtimeOrders quản lý Postgres Changes, rung/banner và đồng bộ API định kỳ 30 giây; sync khi app trở lại foreground.
- useTabNavigation giữ tab từng mount và lịch sử Android Back, giữ vị trí cuộn bằng cách ẩn tab thay vì unmount.
- Dữ liệu đi qua hai đường: Supabase trực tiếp và REST API Next.js. Đây là nguồn chính của các lỗi contract/đồng bộ hiện tại.
- ReceiptModal là màn hình xem trước; thao tác in hiện chỉ hiện Alert, chưa có tích hợp máy in.

Điểm tốt: đã chia màn hình/hooks, TypeScript strict, cleanup channel/timer/listener, có xử lý foreground và đồng bộ bù khi WebSocket gián đoạn. Có thể giữ nền Expo/RN này; chưa cần viết lại app.

## Phát hiện ưu tiên

### M01 — P1: Không có vòng đời session thực sự

App.tsx:40 mặc định isLoggedIn=true. Lần mở app bỏ qua AuthScreen. AuthScreen.tsx:26–40 cho demo đi thẳng; email demo bỏ qua lỗi signInWithPassword. App.tsx:528 logout chỉ đổi boolean, không gọi supabase.auth.signOut hay xóa state.

Hệ quả: giao diện coi người dùng đã đăng nhập trong khi Supabase/API chưa có session. Logout không chấm dứt session thực nếu trước đó đăng nhập thành công. Dữ liệu/form/đơn cũ giữ trong bộ nhớ và có thể xuất hiện lại khi đổi người dùng.

Đề xuất: AuthProvider với trạng thái initializing/authenticated/anonymous, getSession + onAuthStateChange; xử lý tài khoản đổi và token hết hạn. Logout gọi signOut và clear cache/forms/channels. Demo dùng dữ liệu/môi trường riêng, không chỉ bật flag.

supabase.ts:103–108 bật persistSession nhưng không cấp storage adapter native; package.json không có AsyncStorage/SecureStore. Chưa có persistence native được cấu hình rõ. Bổ sung adapter phù hợp và kiểm tra khôi phục session sau cold start. Publishable key không phải secret; điều cần bảo vệ là session và RLS.

### M02 — P1: Mobile chưa tương thích backend đã thêm auth

supabase.ts:83–101 không lấy access token hoặc gắn Authorization. useShopRealtimeOrders.ts:69–71 GET orders không gửi token; App.tsx:305–314 PATCH orders và :339–353 PATCH shops chỉ gửi Content-Type.

Backend mới requireShopOwnerOrAdmin cho GET danh sách/PATCH đơn và PATCH shop. Đăng nhập Supabase chỉ tự gắn token cho Supabase SDK, không tự gắn cho fetch REST này. Mobile không có luồng /api/auth để thiết lập cookie API thay thế.

Hệ quả: các API này nhận 401 khi không có cookie từ bên ngoài; mobile có thể vẫn hiển thị connected cho WebSocket nhưng API quản lý đơn thất bại.

Đề xuất: API client thống nhất, lấy session.access_token và gửi Bearer; phân biệt 401/403/validation/network; xử lý refresh và đăng nhập lại. Backend hiện hỗ trợ kiểm tra Supabase JWT nên không cần tự tạo loại token mới.

App.tsx:210–213 còn select toàn bộ shops, không lọc owner_id. RLS migration 003 cho public đọc quán published, nên query này vẫn đưa quán công khai của chủ khác vào bộ chọn. Lọc theo user ID là cần thiết cho app chủ quán; RLS vẫn là lớp bảo vệ quyền thật.

### M03 — P1: Tự gửi lại request sang production trên lỗi 4xx/5xx

supabase.ts:89–100: khi API dev trả bất kỳ !res.ok, helper gọi lại production với cùng init, kể cả POST/PATCH. Cũng không có timeout và không có idempotency key được cấp chung.

Kiểm chứng mock: dev trả 401 cho PATCH orders -> helper gửi PATCH lần hai sang host production. Dev trả 400 cho POST catalog -> cũng gửi POST lần hai. Không phát request thật trong kiểm chứng.

Hệ quả: validation/auth lỗi ở dev trở thành ghi dữ liệu thật; response bị mất sau khi server đã commit cũng có thể dẫn đến ghi lặp/khác môi trường.

Đề xuất: mỗi build chỉ một backend và một Supabase project rõ ràng. Không tự chuyển môi trường khi lỗi; 4xx phải trả lỗi. Retry có kiểm soát trên cùng backend, mutation cần idempotency và UI pending. Dev mặc định không fallback production.

### M04 — P1: Hiện hóa đơn đã trả tiền trước khi server chấp nhận

App.tsx:287–302 đổi local order và mở printingOrder trước request. :305–315 không kiểm tra res.ok; HTTP 401/403/409/500 không làm fetch reject nên catch không xử lý. Không có rollback hoặc mutation lock.

Kiểm chứng mock: PATCH trả 403, handler vẫn mở receipt có payment_status=paid, local status=completed, không báo lỗi. UI có thể bị poll sửa lại sau đó nhưng phiếu đã hiển thị sai ngay lúc thu ngân thao tác.

Đề xuất: với thanh toán chỉ hiển thị/in phiếu paid sau response thành công, dùng order canonical server trả về; pending theo order ID, chống bấm lặp. Optimistic update các thao tác ít rủi ro phải có snapshot rollback và báo lỗi.

### M05 — P1: Fallback tồn kho/thêm món bỏ mất dữ liệu

CatalogTab.tsx:101–122: fallback khi lỗi network chỉ update is_available, bỏ stock_quantity. HTTP error cũng không được kiểm tra nên không báo lỗi hoặc rollback.

CatalogTab.tsx:176–190: thêm món qua Supabase fallback bỏ stock_quantity dù UI đã nhập; is_available luôn true kể cả tồn nhập 0. HTTP API trả lỗi nghiệp vụ cũng có thể rơi xuống insert trực tiếp, tạo hành vi khác server.

:76–79 sửa giá không kiểm tra error, UI giữ giá mới dù DB từ chối. Upsert tồn gửi cả object item cũ, có nguy cơ ghi đè các trường vừa được thiết bị khác sửa.

Đề xuất: một contract ghi dữ liệu cho catalog, cập nhật tối thiểu trường cần thiết; không đổi đường ghi khi API từ chối. Tồn kho dùng adjustment/delta hoặc optimistic concurrency để không ghi đè lượng đã bán đồng thời. Có pending/error/rollback. Giá 0 phải được chấp nhận hoặc từ chối rõ, không âm thầm đổi thành 35.000 do || 35000 (:135).

### M06 — P1: Khuyến mãi cửa hàng A có thể lưu sang B

App.tsx:140–173 chỉ set promoBanner/welcomePopup nếu quán mới có config; nếu không có thì giữ nguyên state. FlashSale ở :197–201 chỉ đổi itemIds, giữ enabled/title/discount của quán cũ.

Kiểm chứng code hydrate trích nguyên: hydrate quán A có banner/popup/flash, rồi quán B theme_config={} -> cả ba nội dung A còn trong state B. Save :325–351 ghi state đó vào B.

Đề xuất: hàm thuần buildShopDraft(shop) luôn trả đủ defaults cho mọi field; draft khóa theo shopId. Reset draft khi đổi quán, xử lý unsaved changes; không dùng state quán trước làm mặc định cho quán sau.

:165–172 hydrate popup còn bỏ imageUrl/ctaText/badge khác; save ghi lại object draft có thể làm mất cấu hình do web thêm. Hợp nhất schema và round-trip các field được hỗ trợ.

### M07 — P1: Request cũ có thể ghi đè dữ liệu quán mới

App.tsx:207–260 tải shop/catalog/events/orders nhiều bước không có AbortController hoặc request generation ID. Hook :65–105 setOrders và setItems không kiểm tra targetShopId còn đang active. Cleanup channel không hủy HTTP đang chạy.

Kịch bản: mở A, chuyển B; response A đến muộn sau B -> orders/items A xuất hiện dưới header B. Sau logout, response đang chạy cũng có thể cập nhật state.

Đề xuất: cache key gồm userId/shopId; abort khi đổi context, bỏ response có generation không khớp. Reset orders/alert đúng lúc switch; derive shop/header/draft từ cùng context. Có thể dùng query library hoặc tự triển khai guard gọn, không bắt buộc thêm thư viện.

### M08 — P1: Fallback đơn hàng đọc nguồn không còn được backend duy trì

useShopRealtimeOrders.ts:91–104 fallback đọc shops.theme_config.recent_orders thay vì bảng orders. Engine mpos-store hiện tại không ghi recent_orders vào theme_config. Nếu field không tồn tại, fallback setOrders([]), che mất đơn đang có trong UI.

Hook còn nghe UPDATE shops rồi có thể thay toàn bộ orders bằng recent_orders (:166–175). Các read từ API/Realtime/legacy JSON không có version/merge rule thống nhất.

Đề xuất: orders là nguồn duy nhất. Nếu cho SDK đọc trực tiếp, query bảng orders theo shop dưới RLS và session đúng. Khi lỗi giữ dữ liệu gần nhất, đánh dấu stale/offline, không biến lỗi thành danh sách rỗng. Empty result hợp lệ phải được phân biệt với error.

### M09 — P2: Realtime chưa bảo đảm thông báo nền

Hook có Vibration + banner, không có push/local notification integration. AppState listener chỉ sync khi foreground; không thể cam kết nhận đơn khi OS suspend/kill app.

Timer 30s vẫn được đăng ký khi background. setRealtimeStatus('connected') chỉ chứng minh channel subscribe, không chứng minh publication, quyền SELECT hoặc lần sync dữ liệu gần nhất thành công. Không thấy thiết lập publication trong các migration đã đọc; có thể đã bật qua dashboard nhưng cần xác minh trong triển khai.

Đề xuất: nếu chủ quán phải nhận đơn khi khóa máy, thiết kế push từ backend + đăng ký device token; không dựa vào JS timer. Pause polling/refresh đúng AppState; hiển thị last successful sync và stale/error độc lập với trạng thái WebSocket. Vibration/alert nên chạy ngoài state updater để updater thuần.

### M10 — P2: Báo cáo doanh thu dùng ngày UTC và cộng cả đơn chưa trả

OverviewTab.tsx:32–49 dùng toISOString date prefix cho hôm nay; tại Việt Nam 00:00–06:59, ngày UTC vẫn là ngày hôm trước. Label biểu đồ lấy ngày local nhưng nhóm dữ liệu theo UTC nên có thể lệch nhau. validOrders chỉ loại cancelled, gồm cả new/unpaid.

Đề xuất: thống nhất timezone Asia/Ho_Chi_Minh và định nghĩa doanh thu với backend. Tách doanh số đơn tạo khỏi tiền đã thu; chốt dùng created_at hay paid_at theo nghiệp vụ. Aggregate trên backend khi dữ liệu lớn, không cộng mảng lịch sử chưa chắc đầy đủ.

### M11 — P2: Nút in hiện chỉ là mô phỏng

ReceiptModal.tsx:314–319 chỉ Alert 'Đã gửi lệnh in' rồi đóng modal; không có printer/print API. package.json cũng không có thư viện in. Đây là preview, chưa thực hiện lệnh ra máy in.

Đề xuất: đổi wording đúng trạng thái cho đến khi tích hợp. Chọn AirPrint/system print hoặc ESC/POS Bluetooth/LAN theo máy đích. Nếu cần native module, xác định development build thay vì hứa hỗ trợ bằng Expo Go. Chỉ báo thành công theo kết quả thực; có retry và duplicate-print warning phù hợp.

## Hiệu năng, cấu trúc và trải nghiệm

- App.tsx vẫn gom data loading + mutations + nhiều form vào 897 dòng; tách session, shop context, orders data, catalog mutations, shop draft. Các tab giữ vai trò trình bày và tương tác.
- Không cần đổi framework hoặc thêm Redux ngay. Nhu cầu chính là nguồn state/query rõ ràng và một contract API.
- Orders/Catalog dùng .map trong ScrollView, render toàn bộ. Dùng FlatList/SectionList cho danh sách lớn; phân trang lịch sử đơn, analytics và catalog. Query analytics select('*') chưa có range/date filter; số đếm có thể thiếu khi vượt giới hạn trả về của DB.
- memo có ích nhưng không ngăn hidden mounted tabs nhận props và render khi orders/form ở App thay đổi. Chỉ subscribe state cần dùng; tránh tối ưu trước khi đo.
- API sync không setItems nếu server trả items=[] (:79–80), nên xóa món cuối cùng có thể để lại món cũ trong UI. Cần áp dụng cả mảng rỗng khi là response hợp lệ.
- CatalogTab giữ selectedCategoryId khi đổi shop; có thể chọn category cũ không thuộc shop mới rồi add item vào quan hệ sai nếu backend chưa kiểm tra. Reset filter/draft theo shop, server kiểm tra category thuộc shop.
- README mobile chỉ mô tả 3 chức năng cũ và dẫn mobile/.env đã không còn trong tree mới. Cần .env.example, hướng dẫn auth/backend/RLS/Realtime và dev/prod. package.json thiếu script typecheck/test và chưa thấy test mobile/CI cho mobile.
- Snapshot không có cấu hình EAS/release workflow. Nếu mục tiêu phát hành store, cần build profiles, signing và kiểm tra permissions theo các tính năng native thực dùng.
- Date/time Flash Sale nhận chuỗi tự do; cần validate start <= end, giờ/ngày hợp lệ và timezone. Preview chỉ là mô phỏng, không dùng làm chứng cứ rule giảm giá đã được server áp dụng.

## Thứ tự sửa đề xuất

1. AuthProvider + native session storage + logout thật + owner-only shop selector; nối API client gửi Bearer.
2. Bỏ production fallback; xử lý HTTP error/timeout và pending/rollback. Thanh toán chỉ xác nhận bằng response server.
3. Thống nhất orders/catalog write contract; bỏ fallback legacy; thêm guard đổi shop/logout, reset shop draft.
4. Chốt realtime foreground và push background; chọn phương án in thật.
5. Thống nhất shared schema mobile/web/backend, timezone/metrics; phân trang + FlatList; CI và tài liệu.

Không nên ưu tiên làm đẹp thêm màn hình trước ba nhóm đầu vì hiện luồng thu ngân có thể hiển thị kết quả chưa được server chấp nhận.

## Kiểm chứng đã chạy

Lệnh: node --experimental-strip-types /workspace/qlaok-review/mobile-7863dd7/verification/verify.mjs

4 ca pass nghĩa là tái hiện lỗi thành công:
1. HTTP 401 PATCH trên dev bị gửi sang production.
2. HTTP 400 POST trên dev bị gửi sang production.
3. PATCH 403 vẫn mở phiếu paid và không báo lỗi/rollback trong handler.
4. Chuyển shop A -> B thiếu config giữ promotion state A.

Nguồn API helper và callback được trích từ snapshot, network/state setters mock. Không có kết nối production, không mô phỏng đầy đủ React scheduling/native UI. Chưa chạy Expo/device/typecheck/full integration.

Các test cần bổ sung khi sửa: cold-start/expiry/logout; owner A/B; API 401/403/409/500/network; đổi quán lúc request chậm; lưu promotion quán thiếu config; thao tác tồn đồng thời; foreground/background reconnect; ca doanh thu qua 00:00 giờ Việt Nam; máy in lỗi/ngắt kết nối.

