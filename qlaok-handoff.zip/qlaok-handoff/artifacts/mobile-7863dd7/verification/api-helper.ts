const API_BASE_URL = 'http://review-dev.invalid';
const PRODUCTION_API_URL = 'https://review-prod.invalid';
export async function fetchWithApiFallback(
  path: string,
  init?: RequestInit
): Promise<Response> {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const primaryUrl = `${API_BASE_URL}${normalizedPath}`;
  try {
    const res = await fetch(primaryUrl, init);
    if (res.ok || API_BASE_URL === PRODUCTION_API_URL) {
      return res;
    }
  } catch {
    // If primary LAN/localhost dev server is unreachable, fall back to production API
    if (API_BASE_URL === PRODUCTION_API_URL) {
      throw new Error('Không thể kết nối máy chủ API');
    }
  }
  return fetch(`${PRODUCTION_API_URL}${normalizedPath}`, init);
}


