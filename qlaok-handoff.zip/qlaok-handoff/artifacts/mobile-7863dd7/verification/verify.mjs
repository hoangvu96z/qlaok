import assert from 'node:assert/strict';
import fs from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
import {fetchWithApiFallback} from './api-helper.ts';
const calls=[];
globalThis.fetch=async(url,init)=>{calls.push({url,init});return new Response('{}',{status:calls.length===1?401:200})};
await fetchWithApiFallback('/api/orders',{method:'PATCH',body:'{}'});
assert.equal(calls.length,2);assert.match(calls[1].url,/review-prod/);
console.log('CONFIRMED: HTTP 401 on dev replays PATCH against production host (both hosts mocked)');
calls.length=0;
globalThis.fetch=async(url,init)=>{calls.push({url,init});return new Response('{}',{status:calls.length===1?400:200})};
await fetchWithApiFallback('/api/catalog',{method:'POST',body:'{}'});
assert.equal(calls.length,2);
console.log('CONFIRMED: HTTP 400 on dev replays POST against production host');
const fixtures=JSON.parse(fs.readFileSync(new URL('./handler-fixtures.json',import.meta.url)));
function compile(source,bindings){
 const fn=stripTypeScriptTypes('const extracted = '+source+';');
 return Function(...Object.keys(bindings),fn+'; return extracted;')(...Object.values(bindings));
}
let orders=[{id:'order-review',status:'new',payment_status:'unpaid'}],receipt=null,alerts=[];
const handler=compile(fixtures.status,{
 activeShop:{id:'shop-review'},orders,
 setOrders:updater=>{orders=updater(orders)},setPrintingOrder:order=>{receipt=order},
 fetchWithApiFallback:async()=>new Response('{}',{status:403}),
 fetchOrdersFromApi:async()=>{},Alert:{alert:(...args)=>alerts.push(args)}
});
await handler('order-review','completed','paid');
assert.equal(receipt.payment_status,'paid');assert.equal(orders[0].status,'completed');assert.equal(alerts.length,0);
console.log('CONFIRMED: rejected PATCH (403) still opens paid receipt; no error alert/rollback in handler');
let state={};
const hydrate=compile(fixtures.hydrate,Object.fromEntries(['PrimaryColor','LayoutMode','BackgroundStyle','PromoBanner','WelcomePopup','FlashSale'].map(key=>['set'+key,value=>{state[key]=typeof value==='function'?value(state[key]):value}])));
hydrate({vertical:'fnb',theme_config:{promoBanner:{enabled:true,title:'Shop A promo',discountValue:40},welcomePopup:{enabled:true,title:'A popup'},flashSale:{enabled:true,title:'A flash',itemIds:['item-A']}}},[{id:'item-A'}]);
hydrate({vertical:'fnb',theme_config:{}},[{id:'item-B'}]);
assert.equal(state.PromoBanner.title,'Shop A promo');assert.equal(state.WelcomePopup.title,'A popup');assert.equal(state.FlashSale.title,'A flash');
console.log('CONFIRMED: switching shop A -> B without promo config retains A banner/popup/flash-sale fields');

