import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
const sandbox = fs.mkdtempSync(path.join(os.tmpdir(), 'qlaok-review-'));
process.chdir(sandbox);
const dbItems = [{id:'review-item',shop_id:'review-shop',is_available:true,price:50000,stock_quantity:5}];
globalThis.__supabaseMock = { from(table) {
 const q = {select(){return q},order(){return q},eq(){return q},upsert(){return q},update(){return q},
 then(resolve,reject){ return Promise.resolve({data:table==='items'?dbItems:[],error:null}).then(resolve,reject)}};
 return q;
}};
const {dbCreateOrder,dbUpdateOrderStatus}=await import('./mpos-isolated.ts');
const storePath=path.join(sandbox,'.local-db/mpos-store.json');
function reset(){fs.mkdirSync(path.dirname(storePath),{recursive:true});fs.writeFileSync(storePath,JSON.stringify({inventory:{'review-item':{stock_quantity:5,sold_count:0}},orders:[]}))}
function stock(){return JSON.parse(fs.readFileSync(storePath)).inventory['review-item'].stock_quantity}
const line=(quantity=1,unit_price=50000)=>({item_id:'review-item',name_vi:'Review',quantity,unit_price,extra_price:0});
const create=(items,extra={})=>dbCreateOrder({shop_id:'review-shop',table_label:'Test',items,...extra});
reset();let order=await create([line(1,1)]);assert.equal(order.total_amount,1);console.log('CONFIRMED: catalog price 50000, client price 1 -> order total 1');
reset();await create([line(-2)]);assert.equal(stock(),7);console.log('CONFIRMED: quantity -2 increases stock 5 -> 7');
reset();await create([line(4),line(4)]);assert.equal(stock(),0);console.log('CONFIRMED: duplicate lines buy 8 with stock 5; accepted');
reset();await Promise.all([create([line(4)]),create([line(4)])]);assert.equal(stock(),1);console.log('CONFIRMED: concurrent orders buy 8 with stock 5; final stock 1');
reset();order=await create([line(2)]);await dbUpdateOrderStatus(order.id,{status:'cancelled'});assert.equal(stock(),5);
await dbUpdateOrderStatus(order.id,{status:'new'});assert.equal(stock(),5);
await dbUpdateOrderStatus(order.id,{status:'cancelled'});assert.equal(stock(),7);console.log('CONFIRMED: cancel -> reopen -> cancel increases initial stock 5 -> 7');
fs.rmSync(sandbox,{recursive:true,force:true});

