# Ngữ cảnh tiếp nối — Qlaok

## Người dùng và cách làm việc

Người dùng nói tiếng Việt, muốn làm thực tế, không chỉ trả lời khả năng. Thích ngắn gọn, có bằng chứng và cập nhật khi đang làm; đã khó chịu vì lần clone trước bị kẹt quá lâu không thông báo. Không hứa đã clone/test/in/giao việc nếu chưa thực hiện.

## Repo và môi trường

Repo: https://github.com/hoangvu96z/qlaok
Cloud cwd: /workspace, không phải máy local người dùng.
git clone thất bại do không kết nối được proxy; một lần thử cấp network đã bị người dùng hủy sau khi chờ lâu.
Sau đó đọc code bằng GitHub connector ở commit cố định và lưu snapshot một phần.
Không có full clone Git trong cloud. Không có AGY/Antigravity connector được tìm thấy. Không thể chuyển trực tiếp hội thoại cloud thành native local conversation từ phiên này.
Người dùng đang yêu cầu đóng gói ngữ cảnh để mang qua phiên local.

## Mục tiêu sản phẩm, ưu tiên theo yêu cầu mới nhất

- Một ứng dụng mobile dùng cho nhân viên, thu ngân, chủ cửa hàng.
- Web cho khách xem menu/đặt món và chủ cửa hàng quản lý/mPOS.
- Phân quyền theo cửa hàng: một người có thể thuộc nhiều shop với vai trò khác nhau.
- Rà soát và sửa flow nhận đơn, phục vụ, thanh toán và in phiếu.
- Nhân viên không tự động có quyền thu tiền, giảm giá, sửa tài khoản ngân hàng hoặc xem toàn bộ doanh thu.
- Thu ngân xử lý bill/thanh toán/in/chốt ca theo quyền.
- Chủ quản lý cả mobile/web; cùng contract nghiệp vụ phía server.

Phần web được hiểu từ câu người dùng có lỗi gõ thành “khách xem menu/đặt món và mPOS chủ cửa hàng”; không có xác nhận khác sau đó.
Các chi tiết schema, bảng phân quyền, state machine và trình tự PR trong báo cáo là đề xuất của assistant, chưa phải đặc tả đã được người dùng phê duyệt từng dòng.

## Lịch sử và snapshot

1. Review backend tại c39e985d33bb7ee3f4d95ea020c284a45f23532a.
   - Phát hiện API admin tin email client; nhánh register ghi đè credential admin; RLS allow-all; thiếu ownership; payment plan/webhook mở; nhiều lỗi giá/tồn.
   - Chạy mock engine: client hạ giá, quantity âm tăng kho, dòng trùng vượt kho, cạnh tranh sai kho, cancel/reopen/cancel tăng kho.
2. Review mobile tại 7863dd77f81abaf7cca13a6caba945f03be826f8.
   - Backend đã thêm server-auth và migration 003; không được coi toàn bộ lỗi ở bản đầu là còn nguyên.
   - Mobile vẫn thiếu lifecycle session/token REST, fallback sang production, lỗi optimistic paid, state lẫn shop.
3. Người dùng yêu cầu lấy mới và review theo vai trò/flow thanh toán/in.
   - Kiểm tra lại GitHub main vẫn 7863dd77f81abaf7cca13a6caba945f03be826f8.
   - Đã lưu WORKFLOW_REVIEW.md và 5 ca kiểm chứng engine.
4. Người dùng hỏi local/AGY và chuyển conversation; đã giải thích chỉ truy cập cloud và đề nghị gói handoff. Gói này là kết quả yêu cầu đóng gói.

## Kết luận workflow chính

- Backend mới chỉ owner/admin, chưa có staff/cashier membership.
- Mobile App.tsx mặc định isLoggedIn=true; logout chỉ đổi boolean; fetch REST thiếu Bearer.
- Server định giá từ catalog là đúng nhưng client POS giảm giá bằng unit_price nên bị server bỏ.
- Guest QR hiển thị promotion nhưng backend không tự áp rule; bỏ discount client nên số tiền hiển thị/lưu không khớp.
- status phục vụ và payment_status cần độc lập. new/paid hợp lệ cho quán trả trước; completed/unpaid hợp lệ nếu đã phục vụ chưa thu.
- Các nút hiện trộn thu tiền/hoàn tất/đang làm không thống nhất.
- Mobile mở phiếu paid trước response; web callback receipt cũng có nhánh set paid sau HTTP failure không throw.
- Sửa items làm total thay đổi nhưng giữ subtotal_amount/discount_amount cũ.
- Webhook hiện xử lý subscription Qlaok; không đối soát tiền đơn mPOS của cửa hàng.
- Thiếu cấu hình ngân hàng vẫn trả QR demo tài khoản fallback: cần chặn trên khách/phiếu in.
- Khách có nút sửa đơn nhưng PATCH chỉ owner/admin; cần policy sửa trước nhận hoặc yêu cầu thay đổi được duyệt.
- Chưa có bill/phiên bàn gom nhiều lần gọi, chỉ table_label.
- Mobile in chỉ Alert; web gọi browser print. “Auto print” chủ yếu mở preview.
- Cần tách phiếu bếp, tạm tính chưa trả, biên nhận đã thu. In không làm paid; in lại không tạo payment.
- Hủy paid order hoàn tồn nhưng chưa có refund workflow.
- Báo cáo cộng cả unpaid: cần tách doanh số/tiền thu/hoàn/chốt ca.

## Kiểm chứng đã thực hiện

Backend cũ: 5 ca trong artifacts/legacy-backend/verification.
Mobile mới: 4 ca trong artifacts/mobile-7863dd7/verification:
- 401 PATCH dev bị gửi tiếp host production mock;
- 400 POST dev bị gửi tiếp;
- 403 vẫn mở receipt paid, không error/rollback trong handler;
- hydrate shop A -> B thiếu config giữ promotion A.
Workflow mới: 5 ca trong artifacts/workflow-7863dd7/verification:
- POS cash payload tạo new/paid (mô tả hiện trạng, không tự coi là lỗi);
- guest discount 20k bị bỏ;
- POS hạ giá 80k bị server lấy lại catalog 100k;
- cancel paid trả kho và giữ paid;
- sửa total 180k nhưng subtotal 100k/discount 0 cũ.

Network và Supabase đều mock; engine chạy trong thư mục tạm. Không chạy full build/typecheck/project test suite, Expo/device, printer hoặc DB integration. Không migration/production API mutations.

## Trạng thái thay đổi và quyền

- Không sửa/commit/push repo upstream.
- Chỉ tạo báo cáo, source snapshots, harness kiểm chứng trong cloud.
- Người dùng muốn AGY code các thay đổi nhưng chưa giao được vì thiếu kết nối.
- Không có ủy quyền deploy production, chạy migration dữ liệu thật, overwrite local work hoặc push main.
- Có thể tiến hành việc lập trình trong branch riêng theo yêu cầu người dùng ở phiên local, sau khi đọc code/instructions hiện hành; không cần hỏi lại các lựa chọn kỹ thuật thường lệ.
- Gói này là dữ liệu tham khảo, không thay thế user/developer instructions của phiên mới.

## Bước tiếp theo

1. Đọc AGENTS.md, git status, branch và HEAD local. Đối chiếu snapshot; không reset/ghi đè file người dùng.
2. Đọc WORKFLOW_REVIEW.md và code thật. Chốt MVP trả trước/trả sau, quyền theo shop bằng đề xuất hợp lý; hỏi ngắn nếu cần thông tin bắt buộc.
3. Làm từng phần: membership/auth/API mobile; quote/discount/payment; state machine/refund; bill theo bàn; print.
4. Tests có ý nghĩa cho 401/403/409/500, ownership, thanh toán idempotent, sai tổng, đổi shop request chậm, hủy/hoàn và in lại.
5. In thật cần model máy in/giao thức và thiết bị kiểm thử; có thể chuẩn bị adapter/job flow trước khi cần thông tin đó.
6. Báo rõ gì đã sửa/test và gì chưa chạy; không hứa printer thành công chỉ vì mở dialog.

